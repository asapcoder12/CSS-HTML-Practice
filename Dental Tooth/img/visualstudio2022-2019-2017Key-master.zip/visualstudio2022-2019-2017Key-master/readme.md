# Visual Studio Product Keys

### Visual Studio 2022 
 - Enterprise: `VHF9H-NXBBB-638P6-6JHCY-88JWH`
 - Professional: `TD244-P4NB7-YQ6XK-Y8MMM-YWV2J`

### Visual Studio 2019
 - Enterprise `BF8Y8-GN2QH-T84XB-QVY3B-RC4DF` | `KBJFW-NXHK6-W4WJM-CRMQB-G3CD` https://visualstudio.microsoft.com/fr/thank-you-downloading-visual-studio/?sku=Enterprise&rel=16
 - Professional `NYWVH-HT4XC-R2WYW-9Y3CM-X4V3Y` | `NJVYC-BMHX2-G77MM-4XJMR-6Q8QF` https://visualstudio.microsoft.com/fr/thank-you-downloading-visual-studio/?sku=Professional&rel=16

### Visual Studio 2017
 - Enterprise:  `NJVYC-BMHX2-G77MM-4XJMR-6Q8QF` | `N2VYX-9VR2K-T733M-MWD9X-KQCDF`
 - Professional: `KBJFW-NXHK6-W4WJM-CRMQB-G3CDH` | `4F3PR-NFKDB-8HFP7-9WXGY-K77T7`
 - Test Professional: `VG622-NKFP4-GTWPH-XB2JJ-JFHVF`
 - Enterprise: `NJVYC-BMHX2-G77MM-4XJMR-6Q8QF`
 - Professional: `KBJFW-NXHK6-W4WJM-CRMQB-G3CDH`

### Visual Studio 2010 Express
 - Visual Basic: `2KQT8-HV27P-GTTV9-2WBVV-M7X96`
 - C#: `PQT8W-68YB2-MPY6C-9JV9X-42WJV`
 - C++: `6VPJ7-H3CXH-HBTPT-X4T74-3YVY7`
 - Web Developer: `CY8XP-83P66-WCF9D-G3P42-K2VG3`
